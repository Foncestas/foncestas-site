const WA="5519995324387";
const products=[
 {id:1,name:"Box Surpresa",cat:"Boxes",price:80,old:89.90,tag:"Exclusivo VIP",best:true,launch:true,desc:"Box recheada de chocolates escondidos, decoração, fio de fada, balão bubble de 18 polegadas e cartão.",emoji:"BOX"},
 {id:2,name:"Cesta Café da Manhã",cat:"Café da manhã",price:99.90,best:true,desc:"Uma seleção especial para começar o dia com carinho e sabor.",emoji:"CAFÉ"},
 {id:3,name:"Cesta de Chocolates",cat:"Chocolates",price:89.90,best:true,desc:"Uma composição deliciosa para quem ama chocolates e momentos doces.",emoji:"CHOCOLATE"},
 {id:4,name:"Box Romântica",cat:"Românticos",price:129.90,best:true,desc:"Uma experiência romântica preparada com detalhes para surpreender.",emoji:"ROMANCE"},
 {id:5,name:"Platter Especial",cat:"Café da manhã",price:139.90,launch:true,desc:"Platter com itens selecionados para uma comemoração especial.",emoji:"PLATTER"},
 {id:6,name:"Buquê Coreano",cat:"Personalizados",price:119.90,launch:true,desc:"Buquê autoral com estética delicada e montagem artesanal.",emoji:"BUQUÊ"},
 {id:7,name:"Mini Presente",cat:"Presentes",price:41.90,promo:true,desc:"Uma opção delicada para presentear sem deixar o carinho de lado.",emoji:"MIMO"},
 {id:8,name:"Cesta Especial",cat:"Presentes",price:79.90,promo:true,desc:"Uma composição versátil para diferentes ocasiões.",emoji:"CESTA"}
];
const cats=["Todos",...new Set(products.map(p=>p.cat))];
let state={search:"",cat:"Todos",favorites:JSON.parse(localStorage.getItem("foncestas-favs")||"[]")};
const $=s=>document.querySelector(s);
function money(v){return v.toLocaleString("pt-BR",{style:"currency",currency:"BRL"})}
function wa(name){return `https://wa.me/${WA}?text=${encodeURIComponent("Olá Foncestas! Quero pedir o produto: "+name)}`}
function card(p){
 const fav=state.favorites.includes(p.id);
 return `<article class="product">
   <div class="product-img">${p.emoji}</div>
   <div class="product-body"><span class="tag">${p.tag||p.cat}${p.promo?" · promoção":""}</span>
   <h3>${p.name}</h3><div>${p.old?`<span class="old">${money(p.old)}</span>`:""}<span class="price">${money(p.price)}</span></div>
   <div class="card-actions"><button class="btn btn-primary view" data-id="${p.id}">Ver detalhes</button><button class="fav ${fav?"on":""}" data-fav="${p.id}" aria-label="Favoritar">${fav?"♥":"♡"}</button></div></div>
 </article>`;
}
function render(){
 const filtered=products.filter(p=>(state.cat==="Todos"||p.cat===state.cat)&&(p.name+" "+p.cat+" "+p.desc).toLowerCase().includes(state.search.toLowerCase()));
 $("#products").innerHTML=filtered.map(card).join(""); $("#emptyState").hidden=filtered.length>0;
 $("#bestProducts").innerHTML=products.filter(p=>p.best).map(card).join("");
 $("#launchProducts").innerHTML=products.filter(p=>p.launch).map(card).join("");
 $("#favCount").textContent=state.favorites.length;
 document.querySelectorAll(".view").forEach(b=>b.onclick=()=>openProduct(+b.dataset.id));
 document.querySelectorAll("[data-fav]").forEach(b=>b.onclick=()=>toggleFav(+b.dataset.fav));
}
$("#filters").innerHTML=cats.map(c=>`<button class="filter ${c==="Todos"?"active":""}" data-cat="${c}">${c}</button>`).join("");
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{state.cat=b.dataset.cat;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));render()});
$("#searchInput").oninput=e=>{state.search=e.target.value;render()};
$("#clearSearch").onclick=()=>{$("#searchInput").value="";state.search="";render()};
$("#menuBtn").onclick=()=>$("#mobileNav").classList.toggle("open");
document.querySelectorAll("#mobileNav a").forEach(a=>a.onclick=()=>$("#mobileNav").classList.remove("open"));
function toggleFav(id){state.favorites=state.favorites.includes(id)?state.favorites.filter(x=>x!==id):[...state.favorites,id];localStorage.setItem("foncestas-favs",JSON.stringify(state.favorites));render()}
$("#favBtn").onclick=()=>{state.search="";state.cat="Todos";document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x.dataset.cat==="Todos"));const favs=products.filter(p=>state.favorites.includes(p.id));$("#products").innerHTML=favs.length?favs.map(card).join(""):`<p class="empty">Você ainda não adicionou favoritos.</p>`;document.querySelector("#catalogo").scrollIntoView({behavior:"smooth"});document.querySelectorAll(".view").forEach(b=>b.onclick=()=>openProduct(+b.dataset.id));document.querySelectorAll("[data-fav]").forEach(b=>b.onclick=()=>toggleFav(+b.dataset.fav))};
function openProduct(id){const p=products.find(x=>x.id===id);$("#modalContent").innerHTML=`<div class="modal-grid"><div class="product-img">${p.emoji}</div><div><span class="tag">${p.cat}</span><h2>${p.name}</h2><p>${p.desc}</p><p>${p.old?`<span class="old">${money(p.old)}</span>`:""}<strong class="price">${money(p.price)}</strong></p><p>Personalize seu pedido adicionando extras e converse com a Foncestas pelo WhatsApp.</p><a class="btn btn-primary" href="${wa(p.name)}" target="_blank" rel="noopener">Pedir pelo WhatsApp</a></div></div>`;$("#productModal").classList.add("open");$("#productModal").setAttribute("aria-hidden","false")}
$("#modalClose").onclick=()=>{$("#productModal").classList.remove("open");$("#productModal").setAttribute("aria-hidden","true")};
$("#productModal").onclick=e=>{if(e.target.id==="productModal")$("#modalClose").click()};
$("#customWhats").onclick=()=>{const extras=[...document.querySelectorAll(".extras input:checked")].map(x=>x.value);const text="Olá Foncestas! Quero personalizar um presente. Extras: "+(extras.length?extras.join(", "):"quero conversar sobre opções");window.open(`https://wa.me/${WA}?text=${encodeURIComponent(text)}`,"_blank")};
document.querySelector("[data-promo-filter]").onclick=()=>{state.cat="Todos";state.search="promo";$("#searchInput").value="";render()};
$("#year").textContent=new Date().getFullYear();
render();
