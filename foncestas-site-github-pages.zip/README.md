# Foncestas — site institucional + catálogo

Site estático responsivo, sem backend e sem dependências de build. Pode ser publicado gratuitamente no GitHub Pages.

## Estrutura
- `index.html` — páginas/seções e conteúdo
- `styles.css` — identidade visual e responsividade
- `script.js` — catálogo, busca, filtros, favoritos, modal de produto e WhatsApp
- `assets/` — coloque aqui as fotos reais dos produtos

## Como editar produtos
Abra `script.js` e altere o array `products`. Cada produto possui:
- `name`
- `cat`
- `price`
- `old` (opcional)
- `tag` (opcional)
- `best`
- `launch`
- `promo`
- `desc`
- `emoji` (substitua futuramente por uma imagem)

## Como colocar fotos reais
No `card()` e no modal, troque a área de placeholder por `<img src="assets/nome-da-foto.jpg" alt="...">`.

## GitHub Pages
1. Crie um repositório no GitHub, por exemplo `foncestas-site`.
2. Envie todos os arquivos desta pasta para a raiz do repositório.
3. Vá em **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione `main` e `/ (root)` e salve.
6. O GitHub fornecerá o endereço público do site.

## WhatsApp
O número está configurado como `5519995324387`. Os botões já abrem conversas com mensagens pré-preenchidas.

## Observação
A fonte Rainier North 300 foi indicada como fonte da marca. Como ela não está embutida no projeto, a versão pública usa Georgia/serif para títulos e Montserrat para textos. Se você possuir o arquivo/licença da Rainier North, coloque o `.woff2` em `assets/` e ajuste o `@font-face` no CSS.
